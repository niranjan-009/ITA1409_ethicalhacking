import React from 'react';
import { Hero } from './components/Hero';
import { PhaseGrid } from './components/PhaseGrid';
import { DashboardPreview } from './components/DashboardPreview';
import { LogConsole } from './components/LogConsole';
import { ResourcesSection } from './components/ResourcesSection';
import { ToolsSection } from './components/ToolsSection';
import { Shield, Github, Linkedin, Mail } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 selection:bg-emerald-500/30 font-sans">
      <nav className="fixed top-0 w-full z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6 text-emerald-500" />
              <span className="font-bold text-lg tracking-tight text-white">CyberSim<span className="text-emerald-500">.io</span></span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <a href="#" className="hover:text-emerald-400 transition-colors">Simulation</a>
                <a href="#" className="hover:text-emerald-400 transition-colors">Playbooks</a>
                <a href="#tools" className="hover:text-emerald-400 transition-colors">Tools</a>
                <a href="#" className="px-4 py-2 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium transition-colors">
                  Login
                </a>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="pt-16">
        <Hero />
        <PhaseGrid />
        <DashboardPreview />
        <ToolsSection />
        <ResourcesSection />
        <LogConsole />
      </main>

      <footer className="bg-slate-950 border-t border-slate-800 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-6 h-6 text-emerald-500" />
                <span className="font-bold text-xl text-white">CyberSim.io</span>
              </div>
              <p className="text-slate-400 max-w-sm">
                Advanced cybersecurity training platform focused on intrusion detection, threat hunting, and automated incident response workflows.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Modules</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><a href="#" className="hover:text-emerald-400">Intrusion Detection</a></li>
                <li><a href="#" className="hover:text-emerald-400">Threat Investigation</a></li>
                <li><a href="#" className="hover:text-emerald-400">Response Playbooks</a></li>
                <li><a href="#" className="hover:text-emerald-400">Dashboard Creation</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Connect</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-slate-400 hover:text-white transition-colors">
                  <Github className="w-5 h-5" />
                </a>
                <a href="#" className="text-slate-400 hover:text-white transition-colors">
                  <Linkedin className="w-5 h-5" />
                </a>
                <a href="#" className="text-slate-400 hover:text-white transition-colors">
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-slate-500">
            <p>&copy; 2024 CyberSim.io. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-slate-300">Privacy Policy</a>
              <a href="#" className="hover:text-slate-300">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
