import React from 'react';
import { motion } from 'motion/react';

const phases = [
  {
    id: 1,
    title: "Intrusion Detection",
    description: "Simulate and analyze cyberattacks to develop robust detection procedures.",
    tools: ["Security Onion", "Splunk / ELK", "Wireshark"],
    outputs: ["Event logs", "IP traces", "Alert correlations"],
    deliverables: ["Incident Report", "Root Cause Analysis", "Mitigation Steps"],
    color: "emerald"
  },
  {
    id: 2,
    title: "Threat Investigation",
    description: "Deep dive forensics into compromised systems to identify extent of breach.",
    tools: ["Autopsy", "Volatility", "TheHive"],
    outputs: ["Memory dumps", "Disk images", "Malware signatures"],
    deliverables: ["Forensic Timeline", "IOC List", "Attribution Report"],
    color: "cyan"
  },
  {
    id: 3,
    title: "Response & Playbooks",
    description: "Automate incident response and visualize data for decision making.",
    tools: ["Cortex XSOAR", "Jupyter", "Grafana"],
    outputs: ["Automated workflows", "Containment scripts", "Dashboards"],
    deliverables: ["Response Playbook", "Executive Dashboard", "Post-Mortem"],
    color: "violet"
  }
];

const colorVariants: Record<string, string> = {
  emerald: "border-emerald-500/20 bg-emerald-500/5 hover:border-emerald-500/40 text-emerald-400",
  cyan: "border-cyan-500/20 bg-cyan-500/5 hover:border-cyan-500/40 text-cyan-400",
  violet: "border-violet-500/20 bg-violet-500/5 hover:border-violet-500/40 text-violet-400"
};

const badgeVariants: Record<string, string> = {
  emerald: "bg-emerald-500/10 text-emerald-300 border-emerald-500/20",
  cyan: "bg-cyan-500/10 text-cyan-300 border-cyan-500/20",
  violet: "bg-violet-500/10 text-violet-300 border-violet-500/20"
};

const dotColors: Record<string, string> = {
  emerald: "bg-emerald-400",
  cyan: "bg-cyan-400",
  violet: "bg-violet-400"
};

export const PhaseGrid = () => {
  return (
    <div className="py-24 bg-slate-950 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-white mb-4">Simulation Modules</h2>
          <p className="text-slate-400">A structured approach to mastering modern cyber defense operations.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {phases.map((phase, index) => (
            <motion.div
              key={phase.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`p-6 rounded-2xl border ${colorVariants[phase.color]} backdrop-blur-sm transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 group`}
            >
              <div className="text-6xl font-black opacity-10 mb-4 select-none absolute top-4 right-6">
                0{phase.id}
              </div>
              
              <h3 className="text-2xl font-bold mb-3 text-white relative z-10">{phase.title}</h3>
              <p className="text-slate-400 mb-6 text-sm relative z-10">{phase.description}</p>
              
              <div className="space-y-4 relative z-10">
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider opacity-70 mb-2">Tools Stack</h4>
                  <div className="flex flex-wrap gap-2">
                    {phase.tools.map(tool => (
                      <span key={tool} className={`text-xs px-2 py-1 rounded border ${badgeVariants[phase.color]}`}>
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider opacity-70 mb-2">Key Deliverables</h4>
                  <ul className="text-sm space-y-1 text-slate-300">
                    {phase.deliverables.map(item => (
                      <li key={item} className="flex items-center gap-2">
                        <span className={`w-1 h-1 rounded-full ${dotColors[phase.color]}`}></span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
