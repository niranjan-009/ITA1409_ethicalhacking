import React from 'react';
import { motion } from 'motion/react';
import { FileText, Download, ShieldAlert, FileSearch, BookOpen } from 'lucide-react';

const resources = [
  {
    title: "Incident Report Template",
    description: "Standardized format for documenting detection timeline, root cause, and mitigation steps.",
    icon: <FileText className="w-6 h-6 text-emerald-400" />,
    size: "245 KB",
    format: "DOCX"
  },
  {
    title: "Threat Hunting Playbook",
    description: "Step-by-step procedures for investigating common attack vectors and anomalies.",
    icon: <ShieldAlert className="w-6 h-6 text-orange-400" />,
    size: "1.2 MB",
    format: "PDF"
  },
  {
    title: "Forensic Analysis Checklist",
    description: "Comprehensive checklist for memory forensics, disk imaging, and malware analysis.",
    icon: <FileSearch className="w-6 h-6 text-blue-400" />,
    size: "180 KB",
    format: "PDF"
  },
  {
    title: "Response Workflow Guide",
    description: "Visual flowcharts for decision-making during critical security incidents.",
    icon: <BookOpen className="w-6 h-6 text-purple-400" />,
    size: "3.5 MB",
    format: "PDF"
  }
];

export const ResourcesSection = () => {
  return (
    <div className="py-20 bg-slate-900 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Downloadable Resources</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Professional templates and guides to help you standardize your incident response and threat hunting procedures.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {resources.map((resource, index) => (
            <motion.div
              key={resource.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-950 border border-slate-800 p-6 rounded-xl hover:border-emerald-500/30 hover:bg-slate-900/50 transition-all group"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 group-hover:border-slate-700 transition-colors">
                  {resource.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white mb-1 group-hover:text-emerald-400 transition-colors">
                    {resource.title}
                  </h3>
                  <p className="text-slate-400 text-sm mb-4">
                    {resource.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800">
                        {resource.format}
                      </span>
                      <span>{resource.size}</span>
                    </div>
                    <button className="flex items-center gap-2 text-sm font-medium text-emerald-500 hover:text-emerald-400 transition-colors">
                      <Download className="w-4 h-4" />
                      Download
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
