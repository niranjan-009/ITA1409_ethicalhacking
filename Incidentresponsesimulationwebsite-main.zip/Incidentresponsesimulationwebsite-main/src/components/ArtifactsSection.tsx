import React from 'react';
import { motion } from 'motion/react';
import { FileCheck, Activity, Target, Zap } from 'lucide-react';

const artifacts = [
  {
    icon: <FileCheck className="text-emerald-400" />,
    title: "Event Logs",
    desc: "Raw system and network logs capturing the attack footprint."
  },
  {
    icon: <Target className="text-red-400" />,
    title: "IP Traces",
    desc: "Source and destination analysis to pinpoint attacker origin."
  },
  {
    icon: <Activity className="text-blue-400" />,
    title: "Alert Correlations",
    desc: "Linked security events revealing the attack chain."
  },
  {
    icon: <Zap className="text-yellow-400" />,
    title: "Mitigation Steps",
    desc: "Actionable procedures to neutralize threats and harden systems."
  }
];

export const ArtifactsSection = () => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8">
      <div className="flex flex-col md:flex-row gap-8 items-center">
        <div className="md:w-1/3">
            <h3 className="text-2xl font-bold text-white mb-4">Simulation Artifacts</h3>
            <p className="text-slate-400 mb-6">
                Our simulation generates real-world forensic data, providing analysts with the raw material needed to practice genuine threat hunting.
            </p>
            <button className="text-emerald-400 font-semibold hover:text-emerald-300 transition-colors flex items-center gap-2">
                View Sample Report &rarr;
            </button>
        </div>
        
        <div className="md:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {artifacts.map((item, i) => (
                <motion.div 
                    key={item.title}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    viewport={{ once: true }}
                    className="bg-slate-950 p-4 rounded-lg border border-slate-800 hover:border-slate-700 transition-colors"
                >
                    <div className="flex items-start gap-3">
                        <div className="p-2 bg-slate-900 rounded-md">
                            {item.icon}
                        </div>
                        <div>
                            <h4 className="text-white font-medium mb-1">{item.title}</h4>
                            <p className="text-sm text-slate-500">{item.desc}</p>
                        </div>
                    </div>
                </motion.div>
            ))}
        </div>
      </div>
    </div>
  );
};
