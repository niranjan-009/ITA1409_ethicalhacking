import React from 'react';
import { ExternalLink, Server, Database, Activity, Search, Box, Layers } from 'lucide-react';

const tools = [
  {
    name: "Security Onion",
    category: "Intrusion Detection",
    description: "Free and open platform for threat hunting, network security monitoring, and log management.",
    icon: <Server className="w-8 h-8 text-blue-400" />,
    link: "https://securityonionsolutions.com/"
  },
  {
    name: "Splunk",
    category: "SIEM / Analytics",
    description: "The platform for removing the barriers between data and action, enabling observability and security.",
    icon: <Database className="w-8 h-8 text-emerald-400" />,
    link: "https://www.splunk.com/"
  },
  {
    name: "Wireshark",
    category: "Packet Analysis",
    description: "The world's foremost and widely-used network protocol analyzer for deep inspection.",
    icon: <Activity className="w-8 h-8 text-cyan-400" />,
    link: "https://www.wireshark.org/"
  },
  {
    name: "TheHive",
    category: "Incident Response",
    description: "A scalable, open source and free Security Incident Response Platform.",
    icon: <Box className="w-8 h-8 text-yellow-400" />,
    link: "https://thehive-project.org/"
  },
  {
    name: "Elastic (ELK)",
    category: "Log Management",
    description: "Accelerate results that matter, from security to observability and enterprise search.",
    icon: <Layers className="w-8 h-8 text-pink-400" />,
    link: "https://www.elastic.co/"
  },
  {
    name: "Autopsy",
    category: "Digital Forensics",
    description: "The premier open source digital forensics platform for hard drive investigation.",
    icon: <Search className="w-8 h-8 text-purple-400" />,
    link: "https://www.autopsy.com/"
  }
];

export const ToolsSection = () => {
  return (
    <div className="py-24 bg-slate-950" id="tools">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-bold text-white mb-4">Industry Standard Tools</h2>
            <p className="text-slate-400">
              Our simulation environment is built on the same battle-tested tools used by SOC teams worldwide. 
              Mastering these technologies ensures you are ready for real-world scenarios.
            </p>
          </div>
          <button className="px-6 py-2.5 rounded-lg border border-slate-700 hover:border-emerald-500/50 hover:text-emerald-400 text-slate-300 transition-all text-sm font-medium">
            View Compatibility Matrix
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool) => (
            <a 
              key={tool.name}
              href={tool.link}
              target="_blank" 
              rel="noopener noreferrer"
              className="block group h-full"
            >
              <div className="h-full bg-slate-900/40 border border-slate-800 rounded-xl p-6 hover:bg-slate-800/60 hover:border-slate-600 transition-all duration-300 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ExternalLink className="w-4 h-4 text-slate-400" />
                </div>
                
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 shadow-sm group-hover:shadow-md group-hover:border-slate-700 transition-all">
                    {tool.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors">
                      {tool.name}
                    </h3>
                    <span className="text-xs font-semibold text-emerald-500/80 bg-emerald-950/30 px-2 py-0.5 rounded">
                      {tool.category}
                    </span>
                  </div>
                </div>
                
                <p className="text-slate-400 text-sm leading-relaxed">
                  {tool.description}
                </p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};
