import React, { useEffect, useState, useRef } from 'react';
import { Terminal } from 'lucide-react';

const mockLogs = [
  "[INFO] 2023-10-24 08:01:22 - Security Onion - Snort Alert: Possible SQL Injection Attempt detected from IP 192.168.1.105",
  "[WARN] 2023-10-24 08:01:25 - Firewall - Blocked outbound connection to known C2 server 45.33.22.11 on port 4444",
  "[INFO] 2023-10-24 08:02:10 - Splunk - Correlated Event: Multiple failed login attempts followed by successful sudo access (User: admin)",
  "[INFO] 2023-10-24 08:03:05 - Wireshark Capture - Analyzing PCAP: handshake_capture.pcap",
  "[DEBUG] 2023-10-24 08:03:06 - Packet Analysis - TCP Retransmission rate high on interface eth0",
  "[CRIT] 2023-10-24 08:04:12 - IDS - Signature Match: ET EXPLOIT Apache Log4j RCE Attempt",
  "[INFO] 2023-10-24 08:05:00 - System - Automated snapshot triggered for forensic analysis",
  "[INFO] 2023-10-24 08:05:15 - Threat Intel - IP 192.168.1.105 reputation score updated: MALICIOUS",
  "[WARN] 2023-10-24 08:06:22 - Elastic - Storage volume /var/log/suricata reaching capacity (85%)",
  "[INFO] 2023-10-24 08:07:45 - Response Playbook - Executing 'Isolate Host' script on endpoint WKSTN-04"
];

export const LogConsole = () => {
  const [logs, setLogs] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let currentIndex = 0;
    
    const interval = setInterval(() => {
      // Ensure we have a valid index and data
      if (currentIndex < mockLogs.length) {
        const nextLog = mockLogs[currentIndex];
        if (nextLog) {
            setLogs(prev => [...prev, nextLog]);
            currentIndex++;
        }
      }
      
      // Reset logic
      if (currentIndex >= mockLogs.length) {
         // Only reset if we haven't already scheduled a reset or if we want to loop
         // We can just reset index to 0 after a pause, but we need to clear logs too
         // The simplest 'loop' is to clear and start over.
         
         // To avoid rapid firing or issues, let's just clear when we hit the end
         // but wait a bit.
         if (currentIndex === mockLogs.length) {
            // Mark as waiting to reset by incrementing beyond length so we don't re-enter this block
            currentIndex++; 
            setTimeout(() => {
                setLogs([]);
                currentIndex = 0;
            }, 3000);
         }
      }
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="bg-slate-950 py-12 border-t border-slate-800">
      <div className="max-w-4xl mx-auto px-4">
        <div className="rounded-lg overflow-hidden border border-slate-800 bg-slate-900 shadow-2xl font-mono text-xs md:text-sm">
          <div className="bg-slate-800 px-4 py-2 flex items-center justify-between border-b border-slate-700">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-slate-400" />
              <span className="text-slate-300 font-semibold">Incident_Log_Stream --tail -f</span>
            </div>
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
              <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
            </div>
          </div>
          
          <div ref={scrollRef} className="h-64 overflow-y-auto p-4 space-y-2 text-slate-300 scroll-smooth">
            {logs.map((log, i) => {
              if (!log) return null; // Safety check
              const colorClass = log.includes("[CRIT]") ? "text-red-400" : 
                                 log.includes("[WARN]") ? "text-yellow-400" : 
                                 log.includes("[DEBUG]") ? "text-slate-500" : "text-emerald-400";
              return (
                <div key={i} className="break-all animate-in fade-in slide-in-from-bottom-1 duration-300">
                  <span className={colorClass}>{log.split(" - ")[0]}</span>
                  <span className="text-slate-300"> - {log.split(" - ").slice(1).join(" - ")}</span>
                </div>
              );
            })}
            {logs.length === 0 && <span className="animate-pulse text-slate-500">Connecting to log stream...</span>}
            <div className="h-2"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
