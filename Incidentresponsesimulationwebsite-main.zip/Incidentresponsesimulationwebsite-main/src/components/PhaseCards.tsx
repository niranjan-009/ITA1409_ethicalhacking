import React from 'react';
import { motion } from 'motion/react';
import { Shield, Search, FileText, Database, Terminal, Cpu } from 'lucide-react';

const phases = [
  {
    id: 1,
    title: 'Intrusion Detection',
    icon: <Shield className="w-8 h-8 text-emerald-400" />,
    tools: ['Security Onion', 'Splunk / ELK', 'Wireshark'],
    desc: 'Simulate cyberattacks to test detection capabilities using industry-standard IDS/IPS solutions.',
    color: 'border-emerald-500/50',
    bg: 'bg-emerald-500/10'
  },
  {
    id: 2,
    title: 'Threat Investigation',
    icon: <Search className="w-8 h-8 text-blue-400" />,
    tools: ['Log Analysis', 'IP Tracing', 'Correlation'],
    desc: 'Deep dive into event logs and alert correlations to identify root causes and attack vectors.',
    color: 'border-blue-500/50',
    bg: 'bg-blue-500/10'
  },
  {
    id: 3,
    title: 'Response & Playbooks',
    icon: <FileText className="w-8 h-8 text-purple-400" />,
    tools: ['Playbook Dev', 'Dashboarding', 'Mitigation'],
    desc: 'Develop comprehensive incident response procedures and visualize threat data for stakeholders.',
    color: 'border-purple-500/50',
    bg: 'bg-purple-500/10'
  }
];

export const PhaseCards = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {phases.map((phase, i) => (
        <motion.div
          key={phase.id}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.2 }}
          viewport={{ once: true }}
          className={`relative p-6 rounded-2xl border ${phase.color} bg-slate-900/60 backdrop-blur-sm overflow-hidden group hover:bg-slate-800/80 transition-all duration-300`}
        >
          <div className={`absolute top-0 right-0 p-3 rounded-bl-2xl ${phase.bg} opacity-50`}>
            <span className="text-4xl font-black text-white/10">0{phase.id}</span>
          </div>
          
          <div className="mb-4 p-3 inline-block rounded-lg bg-slate-950 border border-slate-800">
            {phase.icon}
          </div>
          
          <h3 className="text-xl font-bold text-white mb-3">{phase.title}</h3>
          <p className="text-slate-400 mb-6 text-sm leading-relaxed">
            {phase.desc}
          </p>
          
          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Tools & Tech</p>
            <div className="flex flex-wrap gap-2">
              {phase.tools.map((tool) => (
                <span key={tool} className="px-2 py-1 text-xs rounded bg-slate-950 border border-slate-800 text-slate-300">
                  {tool}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};
