import React, { useState, useEffect } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Legend
} from 'recharts';

const data = [
  { time: '00:00', attacks: 12, traffic: 240 },
  { time: '04:00', attacks: 18, traffic: 139 },
  { time: '08:00', attacks: 45, traffic: 980 },
  { time: '12:00', attacks: 89, traffic: 1590 },
  { time: '16:00', attacks: 120, traffic: 1200 },
  { time: '20:00', attacks: 65, traffic: 600 },
  { time: '23:59', attacks: 34, traffic: 300 },
];

const alertData = [
  { type: 'Malware', count: 45 },
  { type: 'Phishing', count: 32 },
  { type: 'DDoS', count: 12 },
  { type: 'Unauthorized Access', count: 8 },
];

export const DashboardPreview = () => {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    // Delay rendering slightly to ensure layout is computed
    const timer = setTimeout(() => {
      setIsMounted(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="py-20 bg-slate-900 text-slate-200 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Live Threat Monitor</h2>
          <p className="text-slate-400">Real-time visualization of simulated network traffic and alert correlations.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Traffic Chart */}
          <div className="lg:col-span-2 bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-xl">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></span>
              Network Traffic vs. Attack Vectors
            </h3>
            
            {/* Explicit fixed height container to satisfy Recharts size requirements */}
            <div style={{ width: '100%', height: 300, minHeight: 300 }}>
              {isMounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorTraffic" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorAttacks" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="time" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f1f5f9' }}
                      itemStyle={{ color: '#f1f5f9' }}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="traffic" stroke="#06b6d4" fillOpacity={1} fill="url(#colorTraffic)" />
                    <Area type="monotone" dataKey="attacks" stroke="#ef4444" fillOpacity={1} fill="url(#colorAttacks)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-slate-600">
                  Loading Traffic Data...
                </div>
              )}
            </div>
          </div>

          {/* Alert Distribution */}
          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-xl">
            <h3 className="text-lg font-semibold mb-6 text-white">Alert Distribution</h3>
            
             {/* Explicit fixed height container to satisfy Recharts size requirements */}
            <div style={{ width: '100%', height: 300, minHeight: 300 }}>
              {isMounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={alertData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                    <XAxis type="number" stroke="#64748b" />
                    <YAxis dataKey="type" type="category" width={100} stroke="#64748b" fontSize={12} />
                    <Tooltip 
                       cursor={{fill: '#1e293b'}}
                       contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f1f5f9' }}
                    />
                    <Bar dataKey="count" fill="#10b981" radius={[0, 4, 4, 0]} barSize={20} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-slate-600">
                  Loading Alerts...
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
