import React, { Fragment } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { X, Lock, ArrowRight, User, Key } from 'lucide-react';

interface SimulationModalProps {
  isOpen: boolean;
  closeModal: () => void;
}

export const SimulationModal = ({ isOpen, closeModal }: SimulationModalProps) => {
  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={closeModal}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-slate-900 border border-slate-700 p-8 text-left align-middle shadow-2xl transition-all">
                <div className="flex justify-between items-start mb-6">
                  <Dialog.Title
                    as="h3"
                    className="text-2xl font-bold leading-6 text-white flex items-center gap-2"
                  >
                    <Lock className="w-6 h-6 text-emerald-500" />
                    Access Simulation Lab
                  </Dialog.Title>
                  <button
                    type="button"
                    className="text-slate-400 hover:text-white transition-colors"
                    onClick={closeModal}
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="mt-2">
                  <p className="text-sm text-slate-400 mb-6">
                    Enter your credentials to access the virtualized CyberSim environment. 
                    <br /> <span className="text-xs text-slate-500">*Guest access is limited to the "Intrusion Detection" module.</span>
                  </p>

                  <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wide">Username / Email</label>
                      <div className="relative">
                        <User className="absolute left-3 top-2.5 h-5 w-5 text-slate-500" />
                        <input 
                          type="text" 
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                          placeholder="analyst@cybersim.io"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wide">Access Key</label>
                      <div className="relative">
                        <Key className="absolute left-3 top-2.5 h-5 w-5 text-slate-500" />
                        <input 
                          type="password" 
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                          placeholder="••••••••••••••••"
                        />
                      </div>
                    </div>

                    <div className="pt-4">
                      <button
                        type="submit"
                        className="w-full inline-flex justify-center items-center gap-2 rounded-lg border border-transparent bg-emerald-600 px-4 py-3 text-sm font-semibold text-white hover:bg-emerald-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 transition-all shadow-lg shadow-emerald-500/20"
                        onClick={closeModal}
                      >
                        Launch Environment
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </form>
                  
                  <div className="mt-6 text-center">
                    <a href="#" className="text-xs text-slate-400 hover:text-emerald-400 transition-colors">
                      Request Demo Credentials
                    </a>
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
};
