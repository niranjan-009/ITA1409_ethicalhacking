
  # Incident Response Simulation Website

  This is a code bundle for Incident Response Simulation Website. The original project is available at https://www.figma.com/design/NK1gEl9op68Oy76qddvV3n/Incident-Response-Simulation-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  